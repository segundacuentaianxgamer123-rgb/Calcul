/* app JS - auth + app behavior + chart rendering */
document.addEventListener('DOMContentLoaded', () => {
  const USERS_KEY = 'app_users_v1';
  const CURRENT_KEY = 'app_current_v1';
  const HIST_KEY = (email) => `hist_${email}`;

  const readUsers = () => JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  const writeUsers = (u) => localStorage.setItem(USERS_KEY, JSON.stringify(u));
  const setCurrent = (user) => localStorage.setItem(CURRENT_KEY, JSON.stringify(user));
  const getCurrent = () => JSON.parse(localStorage.getItem(CURRENT_KEY) || 'null');
  const logout = () => localStorage.removeItem(CURRENT_KEY);

  const menuBtn = document.getElementById('menuBtn');
  const sidebar = document.getElementById('sidebar');
  const userSection = document.getElementById('userSection');
  const logoutBtn = document.getElementById('logoutBtn');

  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  const current = getCurrent();
  if (userSection) {
    if (current) {
      userSection.innerHTML = `<h2>${escapeHTML(current.name)}</h2>`;
      if (logoutBtn) logoutBtn.style.display = 'block';
    } else {
      userSection.innerHTML = `<a class="btn-login-menu" href="login.html">Inicia sesión</a>`;
      if (logoutBtn) logoutBtn.style.display = 'none';
    }
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      logout();
      window.location.href = 'login.html';
    });
  }

  const habitForm = document.getElementById('habitForm');
  const resultDiv = document.getElementById('resultado');
  const avisoDiv = document.getElementById('registroAviso');
  const chartCanvas = document.getElementById('habitChart');
  const recomendacionDiv = document.getElementById('recomendacion');
  const textoRecomendacion = document.getElementById('textoRecomendacion');

  let chart = null;

  const loadHistory = () => {
    const c = getCurrent();
    if (c) return JSON.parse(localStorage.getItem(HIST_KEY(c.email)) || '[]');
    return JSON.parse(sessionStorage.getItem('hist_session') || '[]');
  };
  const saveHistory = (arr) => {
    const c = getCurrent();
    if (c) localStorage.setItem(HIST_KEY(c.email), JSON.stringify(arr));
    else sessionStorage.setItem('hist_session', JSON.stringify(arr));
  };
  const sortByDate = (arr) => arr.sort((a, b) => new Date(a.date) - new Date(b.date));

  const renderChartFrom = (hist) => {
    const labels = hist.map(h => h.date);
    const dataIMC = hist.map(h => Number(h.imc.toFixed(2)));
    const dataSueno = hist.map(h => h.sueno);
    const dataEj = hist.map(h => h.ejercicio);

    if (chart) chart.destroy();
    chart = new Chart(chartCanvas, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label:'IMC', data:dataIMC, borderColor:'#ff595e', tension:0.25, pointRadius:4 },
          { label:'Sueño (h)', data:dataSueno, borderColor:'#8ac926', tension:0.25, pointRadius:4 },
          { label:'Ejercicio (min)', data:dataEj, borderColor:'#1982c4', tension:0.25, pointRadius:4 }
        ]
      },
      options:{
        responsive:true,
        maintainAspectRatio:false,
        plugins:{ legend:{ labels:{ color:'white' } } },
        scales:{
          x:{ ticks:{ color:'#cfefff' } },
          y:{ ticks:{ color:'#cfefff' } }
        }
      }
    });
  };

  if (chartCanvas) {
    const hist = sortByDate(loadHistory());
    if (hist.length > 0) renderChartFrom(hist);
  }

  if (habitForm) {
    habitForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const date = document.getElementById('fecha').value;
      const altura = parseFloat(document.getElementById('altura').value);
      const peso = parseFloat(document.getElementById('peso').value);
      const sueno = parseFloat(document.getElementById('sueno').value);
      const ejercicio = parseFloat(document.getElementById('ejercicio').value);

      if (!date || !altura || !peso || isNaN(sueno) || isNaN(ejercicio)) {
        alert('Por favor completa todos los campos correctamente.');
        return;
      }

      const imc = peso / (altura * altura);
      const estado = imc < 18.5 ? 'Bajo peso' : imc < 25 ? 'Normal' : imc < 30 ? 'Sobrepeso' : 'Obesidad';

      resultDiv.innerHTML = `
        <div class="info">
          <p><strong>Fecha:</strong> ${escapeHTML(date)}</p>
          <p><strong>IMC:</strong> ${imc.toFixed(2)} — ${estado}</p>
          <p><strong>Sueño:</strong> ${sueno} horas</p>
          <p><strong>Ejercicio:</strong> ${ejercicio} minutos</p>
        </div>
      `;

      const hist = sortByDate(loadHistory());
      const newRecord = { date, imc: Number(imc.toFixed(2)), sueno, ejercicio };
      hist.push(newRecord);
      saveHistory(hist);

      // --- generar recomendación personalizada ---
      const recomendacion = generarRecomendacion(imc, sueno, ejercicio, hist);
      textoRecomendacion.textContent = recomendacion;
      recomendacionDiv.style.display = 'block';

      avisoDiv.innerHTML = `<div style="color:var(--text)">✅ Registro guardado.</div>`;
      renderChartFrom(hist);
      habitForm.reset();
    });
  }

  // ---------- función para generar recomendación ----------
  function generarRecomendacion(imc, sueno, ejercicio, hist) {
    let msg = "";

    // Peso / IMC
    if (imc < 18.5) msg += "Estás por debajo del peso ideal, intenta comer un poco más equilibrado. ";
    else if (imc < 25) msg += "Tu peso es saludable, ¡sigue así! ";
    else if (imc < 30) msg += "Tienes sobrepeso, cuida tu alimentación y haz más ejercicio. ";
    else msg += "Hay obesidad, busca mejorar hábitos poco a poco. ";

    // Sueño
    if (sueno < 6) msg += "Duerme más, tu cuerpo necesita descanso. ";
    else if (sueno <= 8) msg += "Tus horas de sueño son adecuadas. ";
    else msg += "Dormir demasiado puede afectar tu energía diaria. ";

    // Ejercicio
    if (ejercicio < 30) msg += "Intenta moverte un poco más durante el día. ";
    else if (ejercicio < 60) msg += "Buen esfuerzo, ¡mantén la constancia! ";
    else msg += "Excelente nivel de actividad física. ";

    // Tendencia general
    if (hist.length >= 2) {
      const a = hist[hist.length - 2];
      const b = hist[hist.length - 1];
      if (b.imc > a.imc && b.sueno < a.sueno) msg += "Subiste de peso y dormiste menos, cuida tu descanso.";
      else if (b.imc < a.imc && b.ejercicio > a.ejercicio) msg += "¡Vas progresando, excelente trabajo!";
      else if (b.sueno > a.sueno && b.ejercicio > a.ejercicio) msg += "Estás mejorando tus hábitos generales, sigue así.";
    }

    return msg.trim();
  }

  function escapeHTML(s){ return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
});